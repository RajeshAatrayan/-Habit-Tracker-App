package com.example.rajeshaatrayan.habittracker.data;

import android.provider.BaseColumns;

/**
 * Created by RajeshAatrayan on 26-06-2018.
 */

public final class HabitContract {
    /**
     * HabitContract construcotr
     */
    private HabitContract() {

    }
    public static class HabitEntry implements BaseColumns {
        /**
         * I have mentioned all the column names of the table as follows
         */
        public static final String TABLE_NAME = "habittracker";//table name
        public static final String _ID = BaseColumns._ID;//id column
        public static final String HABIT_NAME = "habit";//habit column
        public static final String HABIT_FREQUENCY = "frequency";//freq coln
        public static final String HABIT_TIMING = "time";//timing  col

        /**
         * Now here i  have mentioned the constants for the timings
         */
        public static final int HABIT_TIME_MORNING = 0;
        public static final int HABIT_TIME_AFTERNOON = 1;
        public static final int HABIT_TIME_EVENING = 2;
        public static final int HABIT_TIME_NIGHT = 3;


    }
}
