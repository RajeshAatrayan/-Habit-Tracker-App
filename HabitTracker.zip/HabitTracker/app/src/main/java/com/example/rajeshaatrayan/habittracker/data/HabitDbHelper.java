package com.example.rajeshaatrayan.habittracker.data;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import com.example.rajeshaatrayan.habittracker.data.HabitContract.HabitEntry;

import java.security.PublicKey;

/**
 * Created by RajeshAatrayan on 26-06-2018.
 */

public class HabitDbHelper extends SQLiteOpenHelper {
    public static final String DATABASE_NAME = "htracker.db";    //database name that we want to create
    public static final int DATABASE_VERSION = 1;              //database version currently we took as 1


    /**
     * HabitDbHelper constructor
     *
     * @param context
     */
    public HabitDbHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    /**
     * overriding the onCreate table
     *
     * @param db
     */

    public void onCreate(SQLiteDatabase db) {
        /**
         * creating the query.
         */

        String SQL_CREATE_HABITTRACKER_TABLE = "CREATE TABLE " + HabitEntry.TABLE_NAME + " (" + HabitEntry._ID + " INTEGER PRIMARY KEY AUTOINCREMENT," +
                HabitEntry.HABIT_NAME + " TEXT NOT NULL," + HabitEntry.HABIT_FREQUENCY + " INTEGER DEFAULT 0,"
                + HabitEntry.HABIT_TIMING + " INTEGER DEFAULT 0 );";
        db.execSQL(SQL_CREATE_HABITTRACKER_TABLE);//it will create the table with the given input paramter as query
    }


    public void onUpgrade(SQLiteDatabase db, int i, int i1) {
        //we havent done this yet!
    }
}
