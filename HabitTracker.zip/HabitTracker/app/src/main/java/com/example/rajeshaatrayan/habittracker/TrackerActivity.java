package com.example.rajeshaatrayan.habittracker;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.support.v7.widget.Toolbar;
import android.view.MenuItem;
import android.view.View;
import android.widget.TextView;

import com.example.rajeshaatrayan.habittracker.data.HabitContract.HabitEntry;
import com.example.rajeshaatrayan.habittracker.data.HabitContract;
import com.example.rajeshaatrayan.habittracker.data.HabitDbHelper;

public class TrackerActivity extends AppCompatActivity {
    private HabitDbHelper mDbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tracker);
        Toolbar mtoolBar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(mtoolBar);
        mDbHelper = new HabitDbHelper(this);
    }

    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.delete_habits, menu);
        return true;
    }

    public void displayInfo() {
        SQLiteDatabase db = mDbHelper.getReadableDatabase();
        /**
         * projection array includes the columns we want to retrieve from the table
         */
        String projection[] = {
                HabitEntry._ID,
                HabitEntry.HABIT_NAME,
                HabitEntry.HABIT_FREQUENCY,
                HabitEntry.HABIT_TIMING
        };
        Cursor cursor = db.query(
                HabitEntry.TABLE_NAME,
                projection,
                null,
                null,
                null,
                null,
                null
        );

        TextView displayView = (TextView) findViewById(R.id.habits_view);
        try {
            displayView.setText("The HabitTracker Table has: " + cursor.getCount() + " entries\n\n");
            int idColumnIndex = cursor.getColumnIndex(HabitEntry._ID);
            int nameColumnIndex = cursor.getColumnIndex(HabitEntry.HABIT_NAME);
            int freqColumnIndex = cursor.getColumnIndex(HabitEntry.HABIT_FREQUENCY);
            int timeColumnIndex = cursor.getColumnIndex(HabitEntry.HABIT_TIMING);
            displayView.append("\t" + "\t" + "\t" + "\t" + HabitEntry._ID + "-"
                    + HabitEntry.HABIT_NAME + "-"
                    + HabitEntry.HABIT_FREQUENCY + "-"
                    + HabitEntry.HABIT_TIMING + "\n");
            while (cursor.moveToNext()) {
                int id = cursor.getInt(idColumnIndex);
                String habname = cursor.getString(nameColumnIndex);
                int freq = cursor.getInt(freqColumnIndex);
                int t = cursor.getInt(timeColumnIndex);
                displayView.append("\t" + "\t" + "\t" + "\t" + id + "-" + habname + "-" + freq + "-" + t + "\n");
            }

        } finally {
            cursor.close();
        }

    }


    protected void onStart() {
        super.onStart();
        displayInfo();
    }

    public void onFloatingButtonClick(View view) {
        Intent intent = new Intent(TrackerActivity.this, EditorActivity.class);
        startActivity(intent);
    }

    public void deleteTable() {
        SQLiteDatabase db = mDbHelper.getWritableDatabase();
        db.execSQL(" DELETE FROM " + HabitEntry.TABLE_NAME);
        TextView displayView = (TextView) findViewById(R.id.habits_view);
        displayView.setText("\t" + "\t" + "\t" + "\t" + "No Entries Found!");
    }

    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.deleteButton:
                deleteTable();
                return true;
        }
        return super.onOptionsItemSelected(item);
    }

}
