package com.example.rajeshaatrayan.habittracker;

import android.content.ContentValues;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.text.TextUtils;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.example.rajeshaatrayan.habittracker.data.HabitContract.HabitEntry;
import com.example.rajeshaatrayan.habittracker.data.HabitContract;
import com.example.rajeshaatrayan.habittracker.data.HabitDbHelper;

public class EditorActivity extends AppCompatActivity {
    EditText mName;
    EditText mfreq;
    Spinner mSpinner;
    private int timing;
    private HabitDbHelper mDbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_editor);
        Toolbar mtoolBar2 = (Toolbar) findViewById(R.id.toolbar2);
        setSupportActionBar(mtoolBar2);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayShowHomeEnabled(true);
        mName = (EditText) findViewById(R.id.enter_habit);
        mfreq = (EditText) findViewById(R.id.enter_freq);
        mSpinner = (Spinner) findViewById(R.id.spinner);
        setupSpinner();
        mDbHelper = new HabitDbHelper(this);

    }

    public void setupSpinner() {
        ArrayAdapter spinnerAdapter = ArrayAdapter.createFromResource(this, R.array.time_day, R.layout.spinner_list);
        spinnerAdapter.setDropDownViewResource(android.R.layout.simple_dropdown_item_1line);
        mSpinner.setAdapter(spinnerAdapter);
        mSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                String selection = (String) adapterView.getItemAtPosition(i);
                if (!TextUtils.isEmpty(selection)) {
                    if (selection.equals("Morning"))
                        timing = 0;
                    else if (selection.equals("Afternoon"))
                        timing = 1;
                    else if (selection.equals("Evening"))
                        timing = 2;
                    else if (selection.equals("Night"))
                        timing = 3;
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });
    }

    public void insertHabitData() {
        try {
            String habitName = mName.getText().toString();
            int freqNumber = Integer.parseInt(mfreq.getText().toString());
            int time = timing;
            SQLiteDatabase db = mDbHelper.getWritableDatabase();
            ContentValues values = new ContentValues();
            values.put(HabitEntry.HABIT_NAME, habitName);
            values.put(HabitEntry.HABIT_FREQUENCY, freqNumber);
            values.put(HabitEntry.HABIT_TIMING, time);
            db.insert(HabitEntry.TABLE_NAME, null, values);
        } catch (NullPointerException e) {

        }
    }

    public boolean onCreateOptionsMenu(Menu menu) {

        getMenuInflater().inflate(R.menu.editor_menu, menu);
        return true;
    }

    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.hit_done:
                insertHabitData();
                Toast toast = Toast.makeText(EditorActivity.this, "Sucessfully Saved", Toast.LENGTH_SHORT);
                toast.show();
                finish();
                return true;
        }
        return super.onOptionsItemSelected(item);
    }
}
